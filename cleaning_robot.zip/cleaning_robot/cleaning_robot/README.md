# 🤖 Autonomous Cleaning Strategy Planner
### A Smart Robot Vacuum Simulator built with Python + Pygame

---

## 📁 Project Structure

```
cleaning_robot/
├── main.py          # Entry point – game loop, rendering, simulation state
├── robot.py         # Robot agent – movement, battery, trail, drawing
├── algorithms.py    # A* and BFS pathfinding + nearest-cell discovery
├── grid.py          # House floor plan layout + cell type definitions
├── ui.py            # Dashboard panel – buttons, slider, stats, popup
└── README.md        # This file
```

---

## 📦 Requirements

- Python 3.8+
- pygame 2.x

Install dependencies:

```bash
pip install pygame
```

---

## ▶️ How to Run

```bash
cd cleaning_robot
python main.py
```

---

## 🎮 Controls

| Key          | Action                        |
|-------------|-------------------------------|
| SPACE        | Start / Pause simulation      |
| R            | Reset to initial state        |
| 1            | Switch to A* algorithm        |
| 2            | Switch to BFS algorithm       |
| + / -        | Increase / decrease speed     |
| ESC          | Quit                          |

Dashboard buttons (right panel):
- **▶ START** – Begin cleaning
- **⏸ PAUSE** – Pause/resume
- **↺ RESET** – Reset simulation
- **A* / BFS toggle** – Choose algorithm
- **Speed slider** – ×1 to ×5 speed

---

## 🏠 House Floor Plan

The simulation features a realistic modern house with:

| Room            | Location         |
|----------------|-----------------|
| Living Room     | Top-left         |
| Kitchen         | Top-right        |
| Dining Area     | Top-center       |
| Hallway         | Middle strip     |
| Master Bedroom  | Bottom-left      |
| Bathroom        | Bottom-center    |
| Bedroom 2       | Bottom-right     |
| Laundry         | Lower-center     |

Furniture includes: sofa, coffee table, TV unit, armchairs, dining table, kitchen counters, beds, wardrobes, desks, bathtub, toilet, washer/dryer.

---

## 🧠 Algorithms Explained

### A* Search (Primary)
A* is an informed search algorithm that uses a **heuristic function** to guide its exploration toward the goal efficiently.

```
f(n) = g(n) + h(n)
```

- `g(n)` = cost from start to current node
- `h(n)` = Manhattan distance heuristic to goal
- `f(n)` = estimated total cost

**Why Manhattan Distance?**  
Because the robot moves in 4 directions on a grid (no diagonals), Manhattan distance (`|Δrow| + |Δcol|`) is the perfect admissible heuristic — it never overestimates.

**Advantages:**
- Finds the shortest path efficiently
- Explores far fewer nodes than BFS
- Optimal when heuristic is admissible

### BFS (Comparison Mode)
Breadth-First Search explores all cells at distance *d* before moving to *d+1*.

- Guaranteed shortest path on unweighted grids
- Explores more nodes than A*
- No heuristic needed

**Comparison in this simulator:**
- BFS explores many more nodes but guarantees shortest path
- A* explores fewer nodes by prioritising promising directions
- Both find optimal paths on this grid

---

## 🔋 Features

### Battery System
- Battery drains 0.08% per cell moved
- Below 15% → robot auto-returns to dock
- Charges at 0.3% per frame at dock
- Resumes cleaning when battery ≥ 95%

### Cleaning Logic
- Robot starts at charging dock
- Finds nearest uncleaned cell using selected algorithm
- Marks each visited cell as cleaned (teal color)
- Leaves animated trail behind it
- Returns to dock when complete

### Dashboard Stats
- Algorithm selected
- Current status (Cleaning / Paused / Charging / Complete)
- Battery % with color-coded bar
- Cleaning progress % with bar
- Cells cleaned / total cells
- Steps taken
- Nodes explored
- Cleaning efficiency %
- Path length

### Visual Effects
- Smooth interpolated robot movement
- Animated glow pulse around robot
- Direction indicator dot
- Teal cleaned-cell overlay
- Glowing charging dock
- Movement trail
- Completion popup with full stats

---

## 📊 Algorithm Performance Comparison

| Metric          | A*       | BFS       |
|----------------|---------|-----------|
| Nodes Explored | ~50-200  | ~500-2000 |
| Path Quality   | Optimal  | Optimal   |
| Speed          | Fast     | Slower    |
| Memory         | Low      | Higher    |

---

## 🚀 Future Enhancements

1. **Dynamic obstacles** – Furniture that moves randomly, forcing replanning
2. **Multi-robot mode** – Two robots dividing the house into zones
3. **Dijkstra / Greedy comparison** – Add more algorithm variants
4. **Dirt/dust system** – Random dirt spawning, robot detects and prioritises
5. **Floor types** – Carpet (slower), hardwood (normal), tile (fast)
6. **Obstacle avoidance with sensor range** – Robot only "sees" N tiles ahead
7. **Save/load floor plans** – Custom house editor
8. **Statistics graph** – Live matplotlib chart of efficiency over time
9. **Sound effects** – Movement, cleaning, charging sounds
10. **Screensaver mode** – Runs automatically on idle

---

## 🎓 Academic Notes

This project demonstrates:

- **Intelligent Agent Design** – autonomous decision-making
- **Search Algorithms** – A* with admissible heuristic, BFS
- **Path Planning** – online replanning after battery recharge
- **Obstacle Avoidance** – collision-free navigation via walkable cell graph
- **State Machine** – IDLE → CLEANING → RETURNING → CHARGING → DONE
- **OOP Design** – modular classes: Robot, Grid, Algorithms, UI

Suitable for: AI/ML coursework, DSA demonstrations, CFAI presentations.
