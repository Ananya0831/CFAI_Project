"""
robot.py - Robot agent for the Autonomous Cleaning Strategy Planner.
Manages robot state, smooth movement interpolation, battery, and cleaning logic.
"""

import pygame
import math
from grid import DOCK, FLOOR, DOOR, CLEANED, get_dock_position


class CleaningRobot:
    """
    Intelligent cleaning robot agent.
    Handles movement, battery, cleaning tracking, and visual rendering.
    """

    BATTERY_DRAIN_PER_STEP = 0.08    # % per cell moved
    LOW_BATTERY_THRESHOLD  = 15.0    # % → return to dock
    CHARGE_RATE_PER_FRAME  = 0.3     # % per frame when docked

    def __init__(self, grid, tile_size):
        self.grid = grid
        self.tile_size = tile_size
        self.ts = tile_size

        dock = get_dock_position()
        self.row, self.col = dock
        self.start_row, self.start_col = dock

        # Pixel position (for smooth animation)
        self.px = self.col * tile_size + tile_size // 2
        self.py = self.row * tile_size + tile_size // 2
        self.target_px = self.px
        self.target_py = self.py

        self.path = []           # Planned path (list of (r,c))
        self.path_index = 0      # Current step in path
        self.moving = False
        self.move_progress = 1.0 # 0.0→1.0 interpolation
        self.move_speed = 0.08   # Fraction per frame (higher = faster)

        self.cleaned = set()     # Set of (r,c) cleaned
        self.cleaned.add((self.row, self.col))
        self.trail = []          # Recent positions for trail effect

        self.battery = 100.0
        self.charging = False
        self.returning_to_dock = False
        self.done = False

        self.steps_taken = 0
        self.nodes_explored = 0
        self.algorithm = 'astar'

        # Visual
        self.pulse_angle = 0.0   # For animated glow
        self.direction = 'right' # Facing direction

        # Direction for robot facing
        self._prev_r = self.row
        self._prev_c = self.col

    def set_path(self, path, explored=0):
        """Set a new movement path and reset index."""
        if path and len(path) > 1:
            self.path = path
            self.path_index = 1   # index 0 is current position
            self.moving = True
            self.move_progress = 0.0
            self.nodes_explored += explored
        else:
            self.moving = False

    def set_speed(self, speed_factor):
        """Adjust movement speed. speed_factor 1-5."""
        self.move_speed = 0.04 + speed_factor * 0.04

    def step_move(self):
        """
        Advance interpolated movement.
        Returns True if a full tile move was completed (trigger next path step).
        """
        if not self.moving:
            return False

        self.move_progress += self.move_speed
        if self.move_progress >= 1.0:
            self.move_progress = 1.0
            # Snap to target cell
            self.row, self.col = self.path[self.path_index - 1]
            self.px = self.target_px
            self.py = self.target_py

            # Mark as cleaned
            if (self.row, self.col) not in self.cleaned:
                self.cleaned.add((self.row, self.col))
                self.battery = max(0, self.battery - self.BATTERY_DRAIN_PER_STEP)
                self.steps_taken += 1

            # Trail
            self.trail.append((self.px, self.py))
            if len(self.trail) > 60:
                self.trail.pop(0)

            # Advance to next step
            if self.path_index < len(self.path):
                self._start_next_move()
            else:
                self.moving = False
                return True   # Path complete

        else:
            # Interpolate pixel position
            if self.path_index >= 1:
                prev_r, prev_c = self.path[self.path_index - 1]
                if self.path_index > 1:
                    prev_r, prev_c = self.path[self.path_index - 2]
                self.px = int(prev_c * self.ts + self.ts // 2 +
                              (self.target_px - (prev_c * self.ts + self.ts // 2)) * self.move_progress)
                self.py = int(prev_r * self.ts + self.ts // 2 +
                              (self.target_py - (prev_r * self.ts + self.ts // 2)) * self.move_progress)
        return False

    def _start_next_move(self):
        """Begin interpolation toward next cell in path."""
        if self.path_index < len(self.path):
            next_r, next_c = self.path[self.path_index]
            # Update direction
            dr = next_r - self.row
            dc = next_c - self.col
            if dc > 0:   self.direction = 'right'
            elif dc < 0: self.direction = 'left'
            elif dr > 0: self.direction = 'down'
            else:        self.direction = 'up'

            self.target_px = next_c * self.ts + self.ts // 2
            self.target_py = next_r * self.ts + self.ts // 2
            self.path_index += 1
            self.move_progress = 0.0

    def is_at_dock(self):
        return (self.row, self.col) == (self.start_row, self.start_col)

    def charge(self):
        """Charge battery when at dock."""
        if self.is_at_dock():
            self.battery = min(100.0, self.battery + self.CHARGE_RATE_PER_FRAME)
            self.charging = True
            if self.battery >= 100.0:
                self.charging = False
                self.returning_to_dock = False
        else:
            self.charging = False

    def needs_recharge(self):
        return self.battery <= self.LOW_BATTERY_THRESHOLD

    def update_pulse(self):
        self.pulse_angle = (self.pulse_angle + 2) % 360

    def draw(self, surface, offset_x, offset_y):
        """Draw the robot with glow, direction indicator, and trail."""
        self.update_pulse()
        ts = self.ts
        ox, oy = offset_x, offset_y

        # ── Trail ────────────────────────────────────────────────
        for i, (tx, ty) in enumerate(self.trail):
            alpha = int(80 * (i / max(len(self.trail), 1)))
            r_size = max(2, int(ts * 0.15 * (i / max(len(self.trail), 1))))
            trail_surf = pygame.Surface((r_size * 2, r_size * 2), pygame.SRCALPHA)
            pygame.draw.circle(trail_surf, (0, 220, 170, alpha), (r_size, r_size), r_size)
            surface.blit(trail_surf, (ox + tx - r_size, oy + ty - r_size))

        # ── Glow pulse ──────────────────────────────────────────
        pulse = abs(math.sin(math.radians(self.pulse_angle)))
        glow_r = int(ts * 0.6 + pulse * ts * 0.15)
        glow_surf = pygame.Surface((glow_r * 2, glow_r * 2), pygame.SRCALPHA)
        alpha_val = int(40 + 20 * pulse)
        pygame.draw.circle(glow_surf, (0, 220, 170, alpha_val), (glow_r, glow_r), glow_r)
        surface.blit(glow_surf, (ox + self.px - glow_r, oy + self.py - glow_r))

        # ── Robot body ──────────────────────────────────────────
        body_r = int(ts * 0.40)
        cx = ox + self.px
        cy = oy + self.py

        # Outer ring (battery color)
        bat_color = (
            (0, 230, 160) if self.battery > 50 else
            (255, 200, 0) if self.battery > 20 else
            (255, 70, 70)
        )
        pygame.draw.circle(surface, bat_color, (cx, cy), body_r + 2)
        pygame.draw.circle(surface, (20, 28, 42), (cx, cy), body_r + 1)

        # Main body
        pygame.draw.circle(surface, (35, 45, 65), (cx, cy), body_r)

        # Direction indicator dot
        dir_offsets = {
            'right': (body_r - 4, 0),
            'left':  (-(body_r - 4), 0),
            'down':  (0, body_r - 4),
            'up':    (0, -(body_r - 4)),
        }
        dx, dy = dir_offsets.get(self.direction, (body_r - 4, 0))
        pygame.draw.circle(surface, (0, 220, 170), (cx + dx, cy + dy), 3)

        # Center dot (active indicator)
        center_color = (0, 220, 170) if not self.charging else (255, 220, 0)
        pygame.draw.circle(surface, center_color, (cx, cy), 4)

        # Charging bolt
        if self.charging:
            font = pygame.font.SysFont('segoeui', 12, bold=True)
            bolt = font.render('⚡', True, (255, 230, 0))
            surface.blit(bolt, (cx - 6, cy - body_r - 14))
