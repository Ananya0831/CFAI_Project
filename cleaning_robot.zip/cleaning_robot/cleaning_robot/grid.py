"""
grid.py - House floor plan layout for the Autonomous Cleaning Strategy Planner
Defines the realistic house layout with rooms, walls, furniture, and doors.
"""

import pygame

# Cell types
FLOOR = 0       # Walkable floor
WALL = 1        # Wall (cannot pass)
FURNITURE = 2   # Furniture obstacle
DOOR = 3        # Door (walkable)
DOCK = 4        # Charging dock
CLEANED = 5     # Cleaned floor tile

# Colors (used by grid renderer)
COLORS = {
    FLOOR:     (30, 35, 48),
    WALL:      (15, 18, 28),
    FURNITURE: (40, 50, 70),
    DOOR:      (55, 70, 90),
    DOCK:      (0, 200, 150),
    CLEANED:   (20, 80, 70),
}

TILE_SIZE = 18  # pixels per cell

# House dimensions (cells)
COLS = 52
ROWS = 42

def create_floor_plan():
    """
    Returns a 2D list (ROWS x COLS) representing the house floor plan.
    0=floor, 1=wall, 2=furniture, 3=door, 4=dock
    """
    grid = [[FLOOR for _ in range(COLS)] for _ in range(ROWS)]

    def fill_rect(r1, c1, r2, c2, cell_type):
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                grid[r][c] = cell_type

    def draw_rect_border(r1, c1, r2, c2, cell_type=WALL):
        for c in range(c1, c2 + 1):
            grid[r1][c] = cell_type
            grid[r2][c] = cell_type
        for r in range(r1, r2 + 1):
            grid[r][c1] = cell_type
            grid[r][c2] = cell_type

    # ── Outer boundary ──────────────────────────────────────────
    fill_rect(0, 0, ROWS - 1, COLS - 1, WALL)
    fill_rect(1, 1, ROWS - 2, COLS - 2, FLOOR)

    # ── ROOM 1: Living Room (top-left)  rows 1-16, cols 1-20 ────
    draw_rect_border(1, 1, 16, 20)
    # door to hallway (bottom wall)
    grid[16][10] = DOOR
    grid[16][11] = DOOR
    # Sofa (rows 3-5, cols 3-9)
    fill_rect(3, 3, 5, 9, FURNITURE)
    # Coffee table
    fill_rect(7, 5, 8, 8, FURNITURE)
    # TV unit (cols 12-18, rows 3-4)
    fill_rect(3, 12, 4, 18, FURNITURE)
    # Armchair
    fill_rect(6, 14, 8, 16, FURNITURE)
    fill_rect(6, 17, 8, 19, FURNITURE)

    # ── ROOM 2: Kitchen (top-right)  rows 1-16, cols 32-50 ──────
    draw_rect_border(1, 32, 16, 50)
    # door to dining
    grid[16][40] = DOOR
    grid[16][41] = DOOR
    # Kitchen counters (L-shape)
    fill_rect(3, 34, 4, 49, FURNITURE)   # top counter
    fill_rect(3, 34, 12, 35, FURNITURE)  # left counter
    # Island
    fill_rect(8, 39, 10, 46, FURNITURE)
    # Fridge
    fill_rect(3, 48, 6, 49, FURNITURE)
    # Sink area (already in counter)

    # ── ROOM 3: Hallway (middle strip)  rows 17-20, cols 1-50 ───
    draw_rect_border(17, 1, 20, 50)
    # Multiple doorways
    grid[17][10] = DOOR; grid[17][11] = DOOR   # from living room
    grid[17][40] = DOOR; grid[17][41] = DOOR   # from kitchen/dining
    grid[20][25] = DOOR; grid[20][26] = DOOR   # to lower hallway

    # ── ROOM 4: Dining Area  rows 1-16, cols 22-30 ──────────────
    draw_rect_border(1, 22, 16, 30)
    grid[16][25] = DOOR; grid[16][26] = DOOR
    grid[1][25] = DOOR; grid[1][26] = DOOR   # connects to kitchen
    # Dining table
    fill_rect(5, 24, 11, 28, FURNITURE)
    # Chairs implied by surrounding space

    # ── ROOM 5: Bedroom (bottom-left)  rows 21-38, cols 1-22 ────
    draw_rect_border(21, 1, 38, 22)
    grid[21][10] = DOOR; grid[21][11] = DOOR
    # Bed (queen)
    fill_rect(23, 3, 30, 14, FURNITURE)
    # Nightstands
    fill_rect(23, 15, 25, 17, FURNITURE)
    fill_rect(28, 15, 30, 17, FURNITURE)
    # Wardrobe
    fill_rect(23, 19, 29, 21, FURNITURE)
    # Desk
    fill_rect(33, 3, 35, 10, FURNITURE)
    # Chair (small)
    fill_rect(33, 11, 35, 13, FURNITURE)

    # ── ROOM 6: Bathroom  rows 21-32, cols 24-35 ────────────────
    draw_rect_border(21, 24, 32, 35)
    grid[21][29] = DOOR; grid[21][30] = DOOR
    # Bathtub
    fill_rect(23, 26, 26, 34, FURNITURE)
    # Toilet
    fill_rect(28, 26, 30, 28, FURNITURE)
    # Sink/vanity
    fill_rect(28, 30, 30, 34, FURNITURE)

    # ── ROOM 7: Second Bedroom  rows 21-38, cols 37-50 ──────────
    draw_rect_border(21, 37, 38, 50)
    grid[21][43] = DOOR; grid[21][44] = DOOR
    # Bed (single)
    fill_rect(23, 39, 29, 47, FURNITURE)
    # Desk
    fill_rect(32, 39, 34, 45, FURNITURE)
    # Wardrobe
    fill_rect(23, 48, 30, 49, FURNITURE)

    # ── Lower hallway  rows 21-38, cols 23-36 ───────────────────
    draw_rect_border(21, 23, 38, 36)
    grid[21][29] = DOOR; grid[21][30] = DOOR   # bathroom
    grid[21][35] = DOOR; grid[21][36] = DOOR   # to second bedroom corridor
    grid[21][23] = DOOR                         # to first bedroom corridor
    grid[38][28] = DOOR; grid[38][29] = DOOR

    # ── Laundry/storage  rows 33-38, cols 24-35 ─────────────────
    draw_rect_border(33, 24, 38, 35)
    grid[33][29] = DOOR; grid[33][30] = DOOR
    fill_rect(35, 26, 37, 28, FURNITURE)  # washer/dryer
    fill_rect(35, 30, 37, 33, FURNITURE)  # shelves

    # ── Charging dock (in hallway) ───────────────────────────────
    grid[19][3] = DOCK

    # ── Fix hallway passages to be open ─────────────────────────
    # Re-open door cells that may have been overwritten
    grid[16][10] = DOOR; grid[16][11] = DOOR
    grid[17][10] = DOOR; grid[17][11] = DOOR
    grid[16][40] = DOOR; grid[16][41] = DOOR
    grid[17][40] = DOOR; grid[17][41] = DOOR
    grid[20][25] = DOOR; grid[20][26] = DOOR
    grid[16][25] = DOOR; grid[16][26] = DOOR
    grid[21][10] = DOOR; grid[21][11] = DOOR
    grid[21][29] = DOOR; grid[21][30] = DOOR
    grid[21][43] = DOOR; grid[21][44] = DOOR

    # internal hallway connections
    grid[17][23] = DOOR
    grid[17][22] = DOOR
    grid[17][30] = DOOR
    grid[17][31] = DOOR
    grid[20][23] = DOOR
    grid[20][24] = DOOR

    return grid


def get_room_labels():
    """Returns list of (row, col, label) for room name overlays."""
    return [
        (8,  8,  "Living Room"),
        (8,  25, "Dining"),
        (8,  41, "Kitchen"),
        (18, 25, "Hallway"),
        (28, 10, "Master Bedroom"),
        (25, 29, "Bathroom"),
        (28, 43, "Bedroom 2"),
        (36, 29, "Laundry"),
    ]


def get_dock_position():
    return (19, 3)


def is_walkable(cell_type):
    return cell_type in (FLOOR, DOOR, DOCK, CLEANED)
