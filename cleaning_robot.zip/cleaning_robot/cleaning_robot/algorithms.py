"""
algorithms.py - A* and BFS pathfinding algorithms for the cleaning robot.
Provides path search, nearest unvisited cell discovery, and exploration stats.
"""

import heapq
from collections import deque
from grid import is_walkable, WALL, FURNITURE


def heuristic(a, b):
    """Manhattan distance heuristic for A*."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def get_neighbors(grid, row, col):
    """Return walkable 4-directional neighbors."""
    rows = len(grid)
    cols = len(grid[0])
    neighbors = []
    for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
        nr, nc = row + dr, col + dc
        if 0 <= nr < rows and 0 <= nc < cols:
            if is_walkable(grid[nr][nc]):
                neighbors.append((nr, nc))
    return neighbors


def astar(grid, start, goal):
    """
    A* Search Algorithm.
    Returns (path, explored_nodes) where path is list of (r,c) from start to goal.
    explored_nodes is count of cells evaluated.
    """
    open_set = []
    heapq.heappush(open_set, (0, start))

    came_from = {}
    g_score = {start: 0}
    f_score = {start: heuristic(start, goal)}
    explored = set()

    while open_set:
        _, current = heapq.heappop(open_set)

        if current in explored:
            continue
        explored.add(current)

        if current == goal:
            # Reconstruct path
            path = []
            while current in came_from:
                path.append(current)
                current = came_from[current]
            path.append(start)
            path.reverse()
            return path, len(explored)

        for neighbor in get_neighbors(grid, current[0], current[1]):
            tentative_g = g_score[current] + 1
            if tentative_g < g_score.get(neighbor, float('inf')):
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                f_score[neighbor] = tentative_g + heuristic(neighbor, goal)
                heapq.heappush(open_set, (f_score[neighbor], neighbor))

    return [], len(explored)   # No path found


def bfs(grid, start, goal):
    """
    Breadth-First Search Algorithm.
    Returns (path, explored_nodes).
    """
    queue = deque([start])
    came_from = {start: None}
    explored = 0

    while queue:
        current = queue.popleft()
        explored += 1

        if current == goal:
            path = []
            while current is not None:
                path.append(current)
                current = came_from[current]
            path.reverse()
            return path, explored

        for neighbor in get_neighbors(grid, current[0], current[1]):
            if neighbor not in came_from:
                came_from[neighbor] = current
                queue.append(neighbor)

    return [], explored


def find_nearest_uncleaned(grid, cleaned, start, algorithm='astar'):
    """
    Find the nearest uncleaned (FLOOR/DOOR) cell using BFS on walkability,
    then plan a path to it using the chosen algorithm.
    Returns (target_cell, path, explored_count) or (None, [], 0) if done.
    """
    from grid import FLOOR, DOOR, CLEANED, DOCK

    rows = len(grid)
    cols = len(grid[0])

    # BFS flood-fill to find nearest uncleaned reachable cell
    queue = deque([start])
    visited = {start}
    target = None

    while queue:
        r, c = queue.popleft()
        if (r, c) not in cleaned and grid[r][c] in (FLOOR, DOOR, DOCK):
            target = (r, c)
            break
        for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
            nr, nc = r + dr, c + dc
            if 0 <= nr < rows and 0 <= nc < cols and (nr, nc) not in visited:
                if is_walkable(grid[nr][nc]):
                    visited.add((nr, nc))
                    queue.append((nr, nc))

    if target is None:
        return None, [], 0

    # Plan path using chosen algorithm
    if algorithm == 'astar':
        path, explored = astar(grid, start, target)
    else:
        path, explored = bfs(grid, start, target)

    return target, path, explored


def count_cleanable_cells(grid):
    """Count total walkable cells in the grid."""
    from grid import FLOOR, DOOR, DOCK
    count = 0
    for row in grid:
        for cell in row:
            if cell in (FLOOR, DOOR, DOCK):
                count += 1
    return count
