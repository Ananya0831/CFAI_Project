"""
main.py - Autonomous Cleaning Strategy Planner
Entry point: initialises Pygame, runs the main simulation loop.

Controls:
  SPACE      - Start / Pause
  R          - Reset
  1/2        - Switch algorithm (A* / BFS)
  +/-        - Speed up / slow down
  ESC        - Quit
"""

import pygame
import sys
import math

from grid import (
    create_floor_plan, get_room_labels, get_dock_position,
    TILE_SIZE, ROWS, COLS,
    FLOOR, WALL, FURNITURE, DOOR, DOCK, CLEANED,
)
from robot import CleaningRobot
from algorithms import find_nearest_uncleaned, count_cleanable_cells
from ui import DashboardUI, BG_DARK, PANEL_BG, ACCENT, TEXT_DIM, TEXT_PRIMARY

# ── Window layout ────────────────────────────────────────────────────────────
DASHBOARD_W = 240
GRID_W      = COLS * TILE_SIZE
GRID_H      = ROWS * TILE_SIZE
WIN_W       = GRID_W + DASHBOARD_W
WIN_H       = max(GRID_H, 640)
FPS         = 60

# ── Cell render colors ───────────────────────────────────────────────────────
CELL_COLORS = {
    FLOOR:     (28, 34, 50),
    WALL:      (10, 13, 22),
    FURNITURE: (38, 48, 68),
    DOOR:      (45, 60, 85),
    DOCK:      (0, 40, 35),
    CLEANED:   (14, 68, 58),
}
WALL_HIGHLIGHT = (20, 24, 38)
FURNITURE_EDGE = (50, 65, 90)


# ── Simulation states ────────────────────────────────────────────────────────
STATE_IDLE     = 'IDLE'
STATE_CLEANING = 'CLEANING'
STATE_PAUSED   = 'PAUSED'
STATE_CHARGING = 'CHARGING'
STATE_RETURNING= 'RETURNING'
STATE_DONE     = 'DONE'


class CleaningSimulator:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WIN_W, WIN_H))
        pygame.display.set_caption("Autonomous Cleaning Strategy Planner")

        self.clock = pygame.time.Clock()
        self.font_room  = pygame.font.SysFont('segoeui', 10)
        self.font_small = pygame.font.SysFont('segoeui', 11)

        # Grid surface (pre-rendered background, redrawn when cells change)
        self.grid_surf = pygame.Surface((GRID_W, GRID_H))

        self._init_simulation()

        self.dashboard = DashboardUI(GRID_W, 0, DASHBOARD_W, WIN_H)
        self.total_cells = count_cleanable_cells(self.grid)

    def _init_simulation(self):
        """(Re)initialise everything for a fresh run."""
        self.grid       = create_floor_plan()
        self.robot      = CleaningRobot(self.grid, TILE_SIZE)
        self.state      = STATE_IDLE
        self.algorithm  = 'astar'

        self.steps        = 0
        self.nodes_total  = 0
        self.path_len     = 0
        self.status_text  = 'Idle – press START'

        self._dirty_grid  = True   # force redraw of grid surface

    # ── Main loop ────────────────────────────────────────────────────────────
    def run(self):
        while True:
            dt = self.clock.tick(FPS)
            self._handle_events()
            self._update()
            self._draw()

    # ── Events ───────────────────────────────────────────────────────────────
    def _handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()

            # Keyboard shortcuts
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit(); sys.exit()
                elif event.key == pygame.K_SPACE:
                    self._toggle_pause()
                elif event.key == pygame.K_r:
                    self._reset()
                elif event.key == pygame.K_1:
                    self.algorithm = 'astar'
                    self.dashboard.algo_toggle.current = 'astar'
                elif event.key == pygame.K_2:
                    self.algorithm = 'bfs'
                    self.dashboard.algo_toggle.current = 'bfs'
                elif event.key in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
                    self.dashboard.speed_slider.value = min(5, self.dashboard.speed_slider.value + 1)
                elif event.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    self.dashboard.speed_slider.value = max(1, self.dashboard.speed_slider.value - 1)

            # Dashboard UI events
            actions = self.dashboard.handle_event(event)
            if actions.get('start'):
                self._start()
            if actions.get('pause'):
                self._toggle_pause()
            if actions.get('reset'):
                self._reset()
            if actions.get('algo'):
                self.algorithm = actions['algo']
                self.robot.algorithm = self.algorithm

    # ── State transitions ────────────────────────────────────────────────────
    def _start(self):
        if self.state in (STATE_IDLE, STATE_PAUSED):
            self.state = STATE_CLEANING
            self.robot.algorithm = self.algorithm
            self.status_text = 'Cleaning…'
            if not self.robot.moving and not self.robot.path:
                self._plan_next_move()

    def _toggle_pause(self):
        if self.state == STATE_CLEANING:
            self.state = STATE_PAUSED
            self.status_text = 'Paused'
        elif self.state == STATE_PAUSED:
            self.state = STATE_CLEANING
            self.status_text = 'Cleaning…'
            if not self.robot.moving:
                self._plan_next_move()

    def _reset(self):
        self.dashboard.completion_popup_active = False
        self.dashboard.popup_anim = 0.0
        self._init_simulation()
        self.total_cells = count_cleanable_cells(self.grid)

    # ── Update ───────────────────────────────────────────────────────────────
    def _update(self):
        if self.state not in (STATE_CLEANING, STATE_RETURNING, STATE_CHARGING):
            return

        # Apply speed
        speed = self.dashboard.speed_slider.value
        self.robot.set_speed(speed)

        # Handle charging at dock
        if self.state == STATE_CHARGING:
            self.robot.charge()
            if self.robot.battery >= 95.0:
                self.robot.charging = False
                self.robot.returning_to_dock = False
                self.state = STATE_CLEANING
                self.status_text = 'Cleaning…'
                self._plan_next_move()
            return

        # Animate robot movement
        path_complete = self.robot.step_move()
        self._dirty_grid = True  # re-render cleaned cells each frame

        if path_complete or not self.robot.moving:
            # Check if we just arrived at dock after returning
            if self.robot.returning_to_dock and self.robot.is_at_dock():
                self.state = STATE_CHARGING
                self.status_text = 'Charging…'
                return

            # Check low battery → go home
            if self.robot.needs_recharge() and not self.robot.returning_to_dock:
                self._go_to_dock()
                return

            # Check done
            if self._all_cleaned():
                # Return to dock
                if not self.robot.is_at_dock():
                    self._go_to_dock(final=True)
                else:
                    self.state = STATE_DONE
                    self.status_text = 'Complete!'
                    self.dashboard.completion_popup_active = True
                return

            # Plan next cleaning move
            if self.state == STATE_CLEANING:
                self._plan_next_move()

    def _plan_next_move(self):
        """Ask algorithms module for the next uncleaned cell and path."""
        target, path, explored = find_nearest_uncleaned(
            self.grid, self.robot.cleaned,
            (self.robot.row, self.robot.col),
            algorithm=self.algorithm
        )
        if target is None:
            self.state = STATE_DONE
            self.status_text = 'Complete!'
            self.dashboard.completion_popup_active = True
            return

        self.nodes_total += explored
        self.path_len = len(path)
        self.robot.set_path(path, explored=0)

    def _go_to_dock(self, final=False):
        """Plan a return path to the charging dock."""
        from algorithms import astar
        dock = get_dock_position()
        path, explored = astar(self.grid, (self.robot.row, self.robot.col), dock)
        self.nodes_total += explored
        self.robot.returning_to_dock = True
        self.robot.set_path(path)
        self.state = STATE_RETURNING
        self.status_text = 'Returning to dock…' if not final else 'Returning (done)…'

    def _all_cleaned(self):
        """Check if all walkable cells have been cleaned."""
        from grid import FLOOR, DOOR, DOCK as DOCK_CELL
        for r in range(ROWS):
            for c in range(COLS):
                if self.grid[r][c] in (FLOOR, DOOR, DOCK_CELL):
                    if (r, c) not in self.robot.cleaned:
                        return False
        return True

    # ── Drawing ──────────────────────────────────────────────────────────────
    def _draw(self):
        self.screen.fill(BG_DARK)

        if self._dirty_grid:
            self._render_grid()
            self._dirty_grid = False

        self.screen.blit(self.grid_surf, (0, 0))

        # Draw robot on main screen
        self.robot.draw(self.screen, 0, 0)

        # Room labels
        self._draw_room_labels()

        # Dashboard
        stats = self._get_stats()
        self.dashboard.draw(self.screen, stats)

        pygame.display.flip()

    def _render_grid(self):
        """Render all tiles to the cached grid surface."""
        ts = TILE_SIZE
        self.grid_surf.fill((8, 11, 20))

        for r in range(ROWS):
            for c in range(COLS):
                cell = self.grid[r][c]
                rect = (c * ts, r * ts, ts, ts)

                # Cleaned override
                if (r, c) in self.robot.cleaned and cell not in (WALL, FURNITURE):
                    col = CELL_COLORS[CLEANED]
                    pygame.draw.rect(self.grid_surf, col, rect)
                    # Subtle sweep line effect
                    sweep_surf = pygame.Surface((ts, ts), pygame.SRCALPHA)
                    pygame.draw.rect(sweep_surf, (0, 200, 160, 18), (0, 0, ts, ts))
                    self.grid_surf.blit(sweep_surf, (c * ts, r * ts))
                    continue

                col = CELL_COLORS.get(cell, (28, 34, 50))
                pygame.draw.rect(self.grid_surf, col, rect)

                # Furniture edge highlight
                if cell == FURNITURE:
                    pygame.draw.rect(self.grid_surf, FURNITURE_EDGE, rect, width=1)
                elif cell == WALL:
                    pygame.draw.rect(self.grid_surf, WALL_HIGHLIGHT, rect, width=1)
                elif cell == DOOR:
                    # Door gap visual
                    door_surf = pygame.Surface((ts, ts), pygame.SRCALPHA)
                    pygame.draw.rect(door_surf, (80, 120, 180, 60), (0, 0, ts, ts))
                    self.grid_surf.blit(door_surf, (c * ts, r * ts))
                elif cell == DOCK:
                    # Glowing dock
                    glow = abs(math.sin(pygame.time.get_ticks() * 0.002))
                    g_surf = pygame.Surface((ts, ts), pygame.SRCALPHA)
                    pygame.draw.rect(g_surf, (0, 200, 150, int(80 + glow * 80)), (0, 0, ts, ts))
                    self.grid_surf.blit(g_surf, (c * ts, r * ts))
                    pygame.draw.rect(self.grid_surf, ACCENT, rect, width=1)

        # Grid lines (very subtle)
        grid_line_surf = pygame.Surface((GRID_W, GRID_H), pygame.SRCALPHA)
        for r in range(0, ROWS + 1):
            pygame.draw.line(grid_line_surf, (255, 255, 255, 6),
                             (0, r * ts), (GRID_W, r * ts))
        for c in range(0, COLS + 1):
            pygame.draw.line(grid_line_surf, (255, 255, 255, 6),
                             (c * ts, 0), (c * ts, GRID_H))
        self.grid_surf.blit(grid_line_surf, (0, 0))

    def _draw_room_labels(self):
        for r, c, label in get_room_labels():
            x = c * TILE_SIZE + 4
            y = r * TILE_SIZE + 2
            txt = self.font_room.render(label, True, (100, 130, 160))
            self.screen.blit(txt, (x, y))

    def _get_stats(self):
        cleaned = len(self.robot.cleaned)
        total   = self.total_cells
        eff     = (cleaned / total * 100) if total > 0 else 0
        return {
            'algorithm':  self.algorithm,
            'status':     self.status_text,
            'cleaned':    cleaned,
            'steps':      self.robot.steps_taken,
            'explored':   self.nodes_total,
            'battery':    self.robot.battery,
            'efficiency': eff,
            'progress':   eff,
            'total_cells':total,
            'path_len':   self.path_len,
        }


if __name__ == '__main__':
    sim = CleaningSimulator()
    sim.run()
