"""
ui.py - Dashboard UI for the Autonomous Cleaning Strategy Planner.
Renders the right-side control panel, stats, buttons, slider, and popups.
"""

import pygame
import math


# ── Color palette ────────────────────────────────────────────────────────────
BG_DARK      = (12, 16, 26)
PANEL_BG     = (18, 24, 38)
PANEL_BORDER = (30, 40, 60)
ACCENT       = (0, 210, 160)
ACCENT2      = (80, 160, 255)
TEXT_PRIMARY = (220, 230, 255)
TEXT_DIM     = (100, 115, 145)
BTN_START    = (0, 180, 120)
BTN_PAUSE    = (200, 160, 0)
BTN_RESET    = (180, 50, 60)
BTN_HOVER_F  = 40    # brightness boost on hover
DANGER       = (255, 70, 70)
WARNING      = (255, 200, 0)
SUCCESS      = (0, 230, 130)


class Button:
    def __init__(self, rect, label, color, text_color=TEXT_PRIMARY, font_size=14):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.color = color
        self.text_color = text_color
        self.font = pygame.font.SysFont('segoeui', font_size, bold=True)
        self.hovered = False
        self.enabled = True

    def draw(self, surface):
        col = self.color
        if self.hovered and self.enabled:
            col = tuple(min(255, c + BTN_HOVER_F) for c in col)
        alpha_surf = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
        radius = 8
        pygame.draw.rect(alpha_surf, (*col, 230 if self.enabled else 100),
                         (0, 0, self.rect.width, self.rect.height), border_radius=radius)
        surface.blit(alpha_surf, self.rect.topleft)
        # Border
        pygame.draw.rect(surface, (*col[:3], 180) if self.enabled else PANEL_BORDER,
                         self.rect, width=1, border_radius=radius)
        txt = self.font.render(self.label, True,
                               self.text_color if self.enabled else TEXT_DIM)
        tr = txt.get_rect(center=self.rect.center)
        surface.blit(txt, tr)

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos) and self.enabled:
                return True
        return False


class AlgoToggle:
    """Toggle between A* and BFS."""
    def __init__(self, x, y, w, h):
        self.rect = pygame.Rect(x, y, w, h)
        self.current = 'astar'
        self.font = pygame.font.SysFont('segoeui', 13, bold=True)

    def draw(self, surface):
        hw = self.rect.width // 2
        # A* side
        a_rect = pygame.Rect(self.rect.x, self.rect.y, hw, self.rect.height)
        b_rect = pygame.Rect(self.rect.x + hw, self.rect.y, hw, self.rect.height)
        a_col = (0, 170, 120) if self.current == 'astar' else (25, 33, 50)
        b_col = (40, 100, 200) if self.current == 'bfs' else (25, 33, 50)
        pygame.draw.rect(surface, a_col, a_rect, border_radius=8)
        pygame.draw.rect(surface, b_col, b_rect, border_radius=8)
        pygame.draw.rect(surface, PANEL_BORDER, self.rect, width=1, border_radius=8)
        t1 = self.font.render('A*', True, TEXT_PRIMARY if self.current == 'astar' else TEXT_DIM)
        t2 = self.font.render('BFS', True, TEXT_PRIMARY if self.current == 'bfs' else TEXT_DIM)
        surface.blit(t1, t1.get_rect(center=a_rect.center))
        surface.blit(t2, t2.get_rect(center=b_rect.center))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                hw = self.rect.width // 2
                if event.pos[0] < self.rect.x + hw:
                    self.current = 'astar'
                else:
                    self.current = 'bfs'
                return True
        return False


class Slider:
    def __init__(self, x, y, w, h, min_val, max_val, initial):
        self.rect = pygame.Rect(x, y, w, h)
        self.min_val = min_val
        self.max_val = max_val
        self.value = initial
        self.dragging = False
        self.font = pygame.font.SysFont('segoeui', 12)

    @property
    def ratio(self):
        return (self.value - self.min_val) / (self.max_val - self.min_val)

    def thumb_x(self):
        return int(self.rect.x + self.ratio * self.rect.width)

    def draw(self, surface):
        # Track
        track_y = self.rect.centery
        pygame.draw.line(surface, PANEL_BORDER,
                         (self.rect.x, track_y), (self.rect.right, track_y), 4)
        pygame.draw.line(surface, ACCENT,
                         (self.rect.x, track_y), (self.thumb_x(), track_y), 4)
        # Thumb
        pygame.draw.circle(surface, ACCENT, (self.thumb_x(), track_y), 8)
        pygame.draw.circle(surface, TEXT_PRIMARY, (self.thumb_x(), track_y), 5)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            tx = self.thumb_x()
            ty = self.rect.centery
            if math.hypot(event.pos[0] - tx, event.pos[1] - ty) < 12:
                self.dragging = True
        if event.type == pygame.MOUSEBUTTONUP:
            self.dragging = False
        if event.type == pygame.MOUSEMOTION and self.dragging:
            ratio = (event.pos[0] - self.rect.x) / self.rect.width
            ratio = max(0, min(1, ratio))
            self.value = round(self.min_val + ratio * (self.max_val - self.min_val))
            return True
        return False


class DashboardUI:
    """Right-side dashboard panel."""

    def __init__(self, x, y, width, height):
        self.rect = pygame.Rect(x, y, width, height)
        self.x = x
        self.y = y
        self.w = width
        self.h = height

        pad = 16
        bw = (width - pad * 3) // 2
        bh = 36
        by = y + 20

        # Buttons row 1
        self.btn_start = Button((x + pad, by, bw, bh), '▶  START', BTN_START)
        self.btn_pause = Button((x + pad * 2 + bw, by, bw, bh), '⏸  PAUSE', BTN_PAUSE)
        by += bh + 10
        self.btn_reset = Button((x + pad, by, width - pad * 2, bh), '↺  RESET', BTN_RESET)
        by += bh + 16

        # Algorithm toggle
        self.algo_toggle = AlgoToggle(x + pad, by, width - pad * 2, 32)
        by += 48

        # Speed slider
        self.speed_label_y = by
        by += 20
        self.speed_slider = Slider(x + pad, by, width - pad * 2, 20, 1, 5, 2)
        by += 36

        self.stats_top_y = by

        # Fonts
        self.font_title  = pygame.font.SysFont('segoeui', 22, bold=True)
        self.font_label  = pygame.font.SysFont('segoeui', 11)
        self.font_value  = pygame.font.SysFont('segoeui', 18, bold=True)
        self.font_small  = pygame.font.SysFont('segoeui', 11)
        self.font_header = pygame.font.SysFont('segoeui', 13, bold=True)

        self.buttons = [self.btn_start, self.btn_pause, self.btn_reset]
        self.completion_popup_active = False
        self.popup_anim = 0.0

    def handle_event(self, event):
        """Returns dict of triggered actions."""
        actions = {}
        if self.btn_start.handle_event(event):
            actions['start'] = True
        if self.btn_pause.handle_event(event):
            actions['pause'] = True
        if self.btn_reset.handle_event(event):
            actions['reset'] = True
        if self.algo_toggle.handle_event(event):
            actions['algo'] = self.algo_toggle.current
        self.speed_slider.handle_event(event)
        return actions

    def draw(self, surface, stats):
        """
        Draw the full dashboard panel.
        stats dict keys: algorithm, status, cleaned, steps, explored,
                         battery, efficiency, progress, total_cells
        """
        pad = 14

        # ── Panel background ─────────────────────────────────────
        panel_surf = pygame.Surface((self.w, self.h), pygame.SRCALPHA)
        pygame.draw.rect(panel_surf, (*PANEL_BG, 245), (0, 0, self.w, self.h), border_radius=0)
        surface.blit(panel_surf, (self.x, self.y))
        # Left border accent
        pygame.draw.line(surface, ACCENT, (self.x, self.y), (self.x, self.y + self.h), 2)

        # ── Title ────────────────────────────────────────────────
        title_y = self.y + 10
        t1 = self.font_header.render('AUTONOMOUS CLEANING', True, ACCENT)
        t2 = self.font_title.render('Strategy Planner', True, TEXT_PRIMARY)
        surface.blit(t1, (self.x + pad, title_y))
        surface.blit(t2, (self.x + pad, title_y + 16))

        # Decorative divider
        pygame.draw.line(surface, PANEL_BORDER,
                         (self.x + pad, title_y + 44),
                         (self.x + self.w - pad, title_y + 44), 1)

        # ── Buttons ──────────────────────────────────────────────
        self.btn_start.draw(surface)
        self.btn_pause.draw(surface)
        self.btn_reset.draw(surface)

        # ── Algorithm toggle ─────────────────────────────────────
        alg_label = self.font_small.render('ALGORITHM', True, TEXT_DIM)
        surface.blit(alg_label, (self.x + pad, self.algo_toggle.rect.y - 14))
        self.algo_toggle.draw(surface)

        # ── Speed slider ─────────────────────────────────────────
        spd_label = self.font_small.render(f'SPEED  ×{self.speed_slider.value}', True, TEXT_DIM)
        surface.blit(spd_label, (self.x + pad, self.speed_label_y))
        self.speed_slider.draw(surface)

        # ── Divider ──────────────────────────────────────────────
        pygame.draw.line(surface, PANEL_BORDER,
                         (self.x + pad, self.stats_top_y - 4),
                         (self.x + self.w - pad, self.stats_top_y - 4), 1)

        # ── Stats grid ───────────────────────────────────────────
        sy = self.stats_top_y
        self._draw_stat(surface, self.x + pad, sy, 'STATUS',
                        stats.get('status', '---'),
                        self._status_color(stats.get('status', '')))
        sy += 52

        self._draw_stat(surface, self.x + pad, sy, 'ALGORITHM',
                        stats.get('algorithm', 'A*').upper(), ACCENT)
        sy += 52

        # Battery (with bar)
        bat = stats.get('battery', 100.0)
        bat_col = SUCCESS if bat > 50 else WARNING if bat > 20 else DANGER
        self._draw_stat(surface, self.x + pad, sy, 'BATTERY', f'{bat:.0f}%', bat_col)
        bar_rect = pygame.Rect(self.x + pad, sy + 38, self.w - pad * 2, 6)
        pygame.draw.rect(surface, PANEL_BORDER, bar_rect, border_radius=3)
        fill_w = int(bar_rect.width * bat / 100)
        if fill_w > 0:
            pygame.draw.rect(surface, bat_col,
                             (bar_rect.x, bar_rect.y, fill_w, bar_rect.height),
                             border_radius=3)
        sy += 58

        # Progress bar
        prog = stats.get('progress', 0.0)
        self._draw_stat(surface, self.x + pad, sy, 'CLEANED', f'{prog:.1f}%', ACCENT2)
        bar_rect2 = pygame.Rect(self.x + pad, sy + 38, self.w - pad * 2, 6)
        pygame.draw.rect(surface, PANEL_BORDER, bar_rect2, border_radius=3)
        fill_w2 = int(bar_rect2.width * prog / 100)
        if fill_w2 > 0:
            pygame.draw.rect(surface, ACCENT2,
                             (bar_rect2.x, bar_rect2.y, fill_w2, bar_rect2.height),
                             border_radius=3)
        sy += 58

        # 2-column stats
        col_w = (self.w - pad * 3) // 2
        self._draw_mini_stat(surface, self.x + pad, sy, 'CELLS CLEANED',
                             str(stats.get('cleaned', 0)))
        self._draw_mini_stat(surface, self.x + pad * 2 + col_w, sy, 'STEPS',
                             str(stats.get('steps', 0)))
        sy += 60

        self._draw_mini_stat(surface, self.x + pad, sy, 'NODES EXPLORED',
                             str(stats.get('explored', 0)))
        self._draw_mini_stat(surface, self.x + pad * 2 + col_w, sy, 'EFFICIENCY',
                             f"{stats.get('efficiency', 0):.0f}%")
        sy += 60

        self._draw_mini_stat(surface, self.x + pad, sy, 'TOTAL CELLS',
                             str(stats.get('total_cells', 0)))
        self._draw_mini_stat(surface, self.x + pad * 2 + col_w, sy, 'PATH LEN',
                             str(stats.get('path_len', 0)))

        # ── Legend ───────────────────────────────────────────────
        legend_y = self.y + self.h - 130
        pygame.draw.line(surface, PANEL_BORDER,
                         (self.x + pad, legend_y), (self.x + self.w - pad, legend_y), 1)
        legend_y += 8
        lh = self.font_small.render('LEGEND', True, TEXT_DIM)
        surface.blit(lh, (self.x + pad, legend_y))
        legend_y += 16
        items = [
            ((30, 35, 48), 'Floor (uncleaned)'),
            ((20, 80, 70), 'Cleaned area'),
            ((40, 50, 70), 'Furniture / Wall'),
            ((0, 210, 160), 'Charging Dock'),
        ]
        for col_item, lbl in items:
            pygame.draw.rect(surface, col_item,
                             (self.x + pad, legend_y, 12, 10), border_radius=2)
            pygame.draw.rect(surface, PANEL_BORDER,
                             (self.x + pad, legend_y, 12, 10), width=1, border_radius=2)
            lt = self.font_small.render(lbl, True, TEXT_DIM)
            surface.blit(lt, (self.x + pad + 16, legend_y))
            legend_y += 16

        # ── Popup ────────────────────────────────────────────────
        if self.completion_popup_active:
            self._draw_popup(surface, stats)

    def _draw_stat(self, surface, x, y, label, value, val_color):
        lbl = self.font_small.render(label, True, TEXT_DIM)
        surface.blit(lbl, (x, y))
        val = self.font_value.render(value, True, val_color)
        surface.blit(val, (x, y + 14))

    def _draw_mini_stat(self, surface, x, y, label, value):
        col_w = (self.w - 14 * 3) // 2
        bg = pygame.Surface((col_w, 48), pygame.SRCALPHA)
        pygame.draw.rect(bg, (25, 33, 52, 200), (0, 0, col_w, 48), border_radius=6)
        surface.blit(bg, (x, y))
        lbl = self.font_small.render(label, True, TEXT_DIM)
        surface.blit(lbl, (x + 6, y + 5))
        val = self.font_header.render(value, True, TEXT_PRIMARY)
        surface.blit(val, (x + 6, y + 22))

    def _status_color(self, status):
        s = status.lower()
        if 'clean' in s and 'complet' not in s:
            return ACCENT
        if 'complet' in s or 'done' in s:
            return SUCCESS
        if 'charg' in s:
            return WARNING
        if 'return' in s or 'dock' in s:
            return ACCENT2
        if 'paus' in s:
            return WARNING
        if 'idle' in s or '---' in s:
            return TEXT_DIM
        return TEXT_PRIMARY

    def _draw_popup(self, surface, stats):
        """Completion popup overlay."""
        self.popup_anim = min(1.0, self.popup_anim + 0.03)
        alpha = int(255 * self.popup_anim)
        pw, ph = 340, 240
        px = self.x - pw - 20
        py = self.y + self.h // 2 - ph // 2

        popup = pygame.Surface((pw, ph), pygame.SRCALPHA)
        pygame.draw.rect(popup, (12, 20, 35, min(alpha, 230)), (0, 0, pw, ph), border_radius=16)
        pygame.draw.rect(popup, (*ACCENT, min(alpha, 180)), (0, 0, pw, ph),
                         width=2, border_radius=16)

        fnt_big = pygame.font.SysFont('segoeui', 24, bold=True)
        fnt_med = pygame.font.SysFont('segoeui', 14)
        fnt_sml = pygame.font.SysFont('segoeui', 12)

        t0 = fnt_big.render('✓  CLEANING COMPLETE', True, SUCCESS)
        popup.blit(t0, t0.get_rect(centerx=pw // 2, y=28))

        pygame.draw.line(popup, (*ACCENT, 120), (20, 64), (pw - 20, 64), 1)

        lines = [
            f"Cells Cleaned:   {stats.get('cleaned', 0)}  /  {stats.get('total_cells', 0)}",
            f"Steps Taken:     {stats.get('steps', 0)}",
            f"Nodes Explored:  {stats.get('explored', 0)}",
            f"Efficiency:      {stats.get('efficiency', 0):.1f}%",
            f"Algorithm:       {stats.get('algorithm', 'A*').upper()}",
        ]
        for i, line in enumerate(lines):
            t = fnt_med.render(line, True, TEXT_PRIMARY)
            popup.blit(t, (28, 78 + i * 24))

        hint = fnt_sml.render("Press R or click RESET to restart", True, TEXT_DIM)
        popup.blit(hint, hint.get_rect(centerx=pw // 2, y=ph - 28))

        surface.blit(popup, (px, py))
